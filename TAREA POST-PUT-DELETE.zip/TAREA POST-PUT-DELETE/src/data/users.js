const users = [
  { id: 1, nombre: 'Andrea', apellido: 'Rodriguez' },
  { id: 2, nombre: 'Juan', apellido: 'Montes' },
  { id: 3, nombre: 'Julie', apellido: 'Leon' }
]

module.exports = users