const { Router } = require('express')
const getUsers = require('../controllers/getUsers.controller')
const getUserById = require('../controllers/getUserById.controller')
const newUser = require('../controllers/createUser.controller')
const editUser = require('../controllers/editUser.controller')
const deleteUser = require('../controllers/deleteUser.controller')


const router = Router()

router.get('/users', getUsers )
router.get('/users/:id', getUserById )



/*
  TODO: Tarea!
*/

router.post('/users/newuser', newUser)
router.put('/users/edituser', editUser)
router.delete('/users/deleteuser', deleteUser)


module.exports = router
