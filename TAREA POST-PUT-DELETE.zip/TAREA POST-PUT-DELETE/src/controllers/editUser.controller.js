const users = require('../data/users')

async function editUser(req, res) {
  const { id, nombre, apellido } = req.body

  const usuario = users.find(user => user.id == id)

  if (usuario) {
    usuario.nombre = nombre
    usuario.apellido = apellido

    res.send({
      message: 'ok',
      data: 'Usuario actualizado correctamente!'
    })
  } else {
    res.send({
      message: 'error',
      data: 'Usuario no encontrado'
    })
  }
}

module.exports = editUser