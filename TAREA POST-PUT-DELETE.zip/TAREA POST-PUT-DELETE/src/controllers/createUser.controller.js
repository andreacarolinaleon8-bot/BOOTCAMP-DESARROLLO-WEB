const users = require('../data/users')

async function newUser(req, res) {
  const { nombre, apellido } = req.body

  const nuevoId = users.length + 1

  users.push({
    id: nuevoId,
    nombre,
    apellido
  })

  res.send({
    message: 'ok',
    data: 'Usuario creado correctamente!'
  })
}

module.exports = newUser