const users = require('../data/users')

async function deleteUser(req, res) {
  const { id } = req.body

  const index = users.findIndex(user => user.id == id)

  if (index !== -1) {
    users.splice(index, 1)

    res.send({
      message: 'ok',
      data: 'Usuario eliminado correctamente!'
    })
  } else {
    res.send({
      message: 'error',
      data: 'Usuario no encontrado'
    })
  }
}

module.exports = deleteUser